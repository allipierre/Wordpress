<?php
$MLANG['default']['ll_ref'] = 'LLL:EXT:lang/locallang_mod_system.xlf';
$MCONF['defaultMod'] = 'list';
$MCONF['name'] = 'system';
$MCONF['access'] = 'admin';
