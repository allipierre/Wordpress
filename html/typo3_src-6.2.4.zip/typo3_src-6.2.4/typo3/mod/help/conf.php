<?php
$MLANG['default']['ll_ref'] = 'LLL:EXT:lang/locallang_mod_help.xlf';
$MCONF['defaultMod'] = 'welcome';
$MCONF['name'] = 'help';
